﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using $ext_safeprojectname$.Application.Common.Interfaces;

namespace $safeprojectname$.Persistence.AzureBlobStorage;
public class AzureBlobStorageService : IApplicationBlobStorage
{
}
